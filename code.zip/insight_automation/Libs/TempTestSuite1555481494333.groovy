import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import internal.GlobalVariable as GlobalVariable

Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/015_ManageDashboard')

suiteProperties.put('name', '015_ManageDashboard')

suiteProperties.put('description', '\uAC8C\uC2DC\uD310\uAD00\uB9AC')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())



RunConfiguration.setExecutionSettingFile("D:\\insight_automation\\Reports\\015_ManageDashboard\\20190417_151134\\execution.properties")

TestCaseMain.beforeStart()

TestCaseMain.startTestSuite('Test Suites/015_ManageDashboard', suiteProperties, [new TestCaseBinding('Test Cases/Admin Site/AD_01_002_Admin_Login(Valid Account)', 'Test Cases/Admin Site/AD_01_002_Admin_Login(Valid Account)',  null), new TestCaseBinding('Test Cases/Admin Site/AD_01_005_Admin_Go_Insight_2.0', 'Test Cases/Admin Site/AD_01_005_Admin_Go_Insight_2.0',  null), new TestCaseBinding('Test Cases/Admin Site/AD_91_001_Admin_DashBoard_ApplicantNotice_register', 'Test Cases/Admin Site/AD_91_001_Admin_DashBoard_ApplicantNotice_register',  null), new TestCaseBinding('Test Cases/Admin Site/AD_91_002_Admin_DashBoard_ApplicantNotice_delete', 'Test Cases/Admin Site/AD_91_002_Admin_DashBoard_ApplicantNotice_delete',  null), new TestCaseBinding('Test Cases/Admin Site/AD_92_001_Admin_DashBoard_ApplicantQnA_register', 'Test Cases/Admin Site/AD_92_001_Admin_DashBoard_ApplicantQnA_register',  null), new TestCaseBinding('Test Cases/Admin Site/AD_92_002_Admin_DashBoard_ApplicantQnA_delete', 'Test Cases/Admin Site/AD_92_002_Admin_DashBoard_ApplicantQnA_delete',  null), new TestCaseBinding('Test Cases/Admin Site/AD_93_001_Admin_DashBoard_ApplicantFAQ_register', 'Test Cases/Admin Site/AD_93_001_Admin_DashBoard_ApplicantFAQ_register',  null), new TestCaseBinding('Test Cases/Admin Site/AD_93_002_Admin_DashBoard_ApplicantFAQ_delete', 'Test Cases/Admin Site/AD_93_002_Admin_DashBoard_ApplicantFAQ_delete',  null), new TestCaseBinding('Test Cases/Admin Site/AD_94_001_Admin_DashBoard_EvalNotice_register', 'Test Cases/Admin Site/AD_94_001_Admin_DashBoard_EvalNotice_register',  null), new TestCaseBinding('Test Cases/Admin Site/AD_94_002_Admin_DashBoard_EvalNotice_delete', 'Test Cases/Admin Site/AD_94_002_Admin_DashBoard_EvalNotice_delete',  null), new TestCaseBinding('Test Cases/Admin Site/AD_95_001_Admin_DashBoard_EvalQnA_register', 'Test Cases/Admin Site/AD_95_001_Admin_DashBoard_EvalQnA_register',  null), new TestCaseBinding('Test Cases/Admin Site/AD_95_002_Admin_DashBoard_EvalQnA_delete', 'Test Cases/Admin Site/AD_95_002_Admin_DashBoard_EvalQnA_delete',  null), new TestCaseBinding('Test Cases/Admin Site/AD_96_001_Admin_DashBoard_Popup_register', 'Test Cases/Admin Site/AD_96_001_Admin_DashBoard_Popup_register',  null), new TestCaseBinding('Test Cases/Admin Site/AD_96_002_Admin_DashBoard_Popup_delete', 'Test Cases/Admin Site/AD_96_002_Admin_DashBoard_Popup_delete',  null), new TestCaseBinding('Test Cases/ETC/Kill_Process', 'Test Cases/ETC/Kill_Process',  null)])
