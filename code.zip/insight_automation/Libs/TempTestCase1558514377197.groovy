import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\user\\AppData\\Local\\Temp\\Katalon\\Test Cases\\Company Site\\CP_02_002_Application_RegistResume_Signup(New)\\20190522_173937\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

not_run: WebUI.callTestCase(findTestCase('Company Site/CP_02_001_Application_PrivacyAgree(All Agree)'), [:], FailureHandling.STOP_ON_FAILURE)

//WebUI.openBrowser(null)
WebUI.switchToWindowTitle('지원서 작성')

WebUI.maximizeWindow()

WebUI.click(findTestObject('Page_Company_Application_registResume_AccountInfo/button_jobnoticename'))

WebUI.delay(1)

'공고명'
WebUI.setText(findTestObject('Page_Company_Application_registResume_AccountInfo/input__name'), applicantname)

'성명'
WebUI.focus(findTestObject('Page_Company_Application_registResume_AccountInfo/button_select_jobnotice', [('jobnoticename') : jobnoticename]))

WebUI.click(findTestObject('Page_Company_Application_registResume_AccountInfo/button_select_jobnotice', [('jobnoticename') : jobnoticename]))

'개인정보 제공동의'
WebUI.click(findTestObject('Object Repository/Page_Company_Application_registResume_AccountInfo/Page_dialog_personal_agreement/button_agreement'))

WebUI.delay(1)

WebUI.click(findTestObject('Object Repository/Page_Company_Application_registResume_AccountInfo/Page_dialog_personal_agreement/span_agreementItem_1'))

WebUI.click(findTestObject('Object Repository/Page_Company_Application_registResume_AccountInfo/Page_dialog_personal_agreement/span_agreementItem_2'))

WebUI.click(findTestObject('Object Repository/Page_Company_Application_registResume_AccountInfo/Page_dialog_personal_agreement/span_agreementItem_3'))

WebUI.delay(1)

WebUI.click(findTestObject('Object Repository/Page_Company_Application_registResume_AccountInfo/Page_dialog_personal_agreement/button_agreement_save'))

WebUI.click(findTestObject('Object Repository/Page_Company_Application_registResume_AccountInfo/Page_dialog_personal_agreement/button_agreement_save_confirm'))

'휴대전화'
WebUI.setText(findTestObject('Page_Company_Application_registResume_AccountInfo/input__mobile1'), phone1)

WebUI.setText(findTestObject('Page_Company_Application_registResume_AccountInfo/input__mobile2'), phone2)

WebUI.setText(findTestObject('Page_Company_Application_registResume_AccountInfo/input__mobile3'), phone3)

'이메일'
WebUI.setText(findTestObject('Page_Company_Application_registResume_AccountInfo/input__email'), email)

WebUI.delay(1)

WebUI.setText(findTestObject('Page_Company_Application_registResume_AccountInfo/input_ _emailConfirm'), email)

WebUI.delay(1)

'비밀번호'
WebUI.setText(findTestObject('Page_Company_Application_registResume_AccountInfo/input__password'), password)

WebUI.delay(1)

WebUI.setText(findTestObject('Page_Company_Application_registResume_AccountInfo/input_ _passwordConfirm'), password)

WebUI.delay(1)

'지원서 작성'
WebUI.focus(findTestObject('Page_Company_Application_registResume_AccountInfo/button_ submit'))

WebUI.click(findTestObject('Page_Company_Application_registResume_AccountInfo/button_ submit'))

WebUI.delay(1)

WebUI.switchToWindowTitle('지원서 작성')

WebUI.focus(findTestObject('Page_Company_Application_registResume_AccountInfo/button_modal_submit'))

WebUI.click(findTestObject('Page_Company_Application_registResume_AccountInfo/button_modal_submit'))

String Step2Title = '이력서 작성 | ' + jobnoticename

WebUI.switchToWindowTitle(Step2Title)

WebUI.verifyTextPresent('지원자', false)

''', 'Test Cases/Company Site/CP_02_002_Application_RegistResume_Signup(New)', new TestCaseBinding('Test Cases/Company Site/CP_02_002_Application_RegistResume_Signup(New)',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
