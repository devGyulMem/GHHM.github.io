import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\user\\AppData\\Local\\Temp\\Katalon\\Test Cases\\Admin Site\\AD_05_001_Recruit_Rating_Scale\\20190516_175642\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

not_run: WebUI.callTestCase(findTestCase('Admin Site/AD_01_002_Admin_Login(Valid Account)'), [('admin_ID') : GlobalVariable.AdminSiteID
        , ('admin_password') : GlobalVariable.AdminSitePW], FailureHandling.CONTINUE_ON_FAILURE)

not_run: WebUI.callTestCase(findTestCase('Admin Site/AD_01_005_Admin_Go_Insight_2.0'), [:], FailureHandling.CONTINUE_ON_FAILURE)

'평가척도 설정'
not_run: CustomKeywords.'userdefinepkg.customElementHandling.clickUsingJS'(findTestObject('Object Repository/Page_Admin_Manager_Recruit_RatingScale/a_rating_scale'), 
    0)

not_run: WebUI.delay(1)

/*
 * 사용 중 평가척도
 * */
'신규 set 추가'
WebUI.click(findTestObject('Page_Admin_Manager_Recruit_RatingScale/button_new_set'))

time = CustomKeywords.'userdefinepkg.timeExpression.getHMSCurrentTime'()

title = ('명칭' + time)

explanation = ('설명' + time)

WebUI.delay(1)

WebUI.setText(findTestObject('Page_Admin_Manager_Recruit_RatingScale/input_ Set _ratingScaleName'), title)

WebUI.setText(findTestObject('Page_Admin_Manager_Recruit_RatingScale/textarea_ Set _explanation'), explanation)

WebUI.setText(findTestObject('Object Repository/Page_Admin_Manager_Recruit_RatingScale/input_ratingScaleName'), '평가척도 명칭')

WebUI.setText(findTestObject('Object Repository/Page_Admin_Manager_Recruit_RatingScale/input_ratingScaleValue'), '50')

WebUI.setText(findTestObject('Object Repository/Page_Admin_Manager_Recruit_RatingScale/input_explanation'), '평가척도 기준 설명')

'저장'
WebUI.click(findTestObject('Page_Admin_Manager_Recruit_RatingScale/button_save'))

WebUI.click(findTestObject('Page_Admin_Manager_Recruit_RatingScale/button_save_confirm'))

WebUI.delay(1)

'체크박스 선택'
WebUI.click(findTestObject('Page_Admin_Manager_Recruit_RatingScale/input__popCheck'))

WebUI.delay(1)

'선택 삭제'
WebUI.click(findTestObject('Page_Admin_Manager_Recruit_RatingScale/button_delete_selected'))

WebUI.click(findTestObject('Page_Admin_Manager_Recruit_RatingScale/button_delete_selected_confirm'))

WebUI.delay(1)

WebUI.click(findTestObject('Page_Admin_Manager_Recruit_RatingScale/button_confirm'))

// 사용 여부 기능 off
xpath = (('(.//*[normalize-space(text()) and normalize-space(.)=\\'' + explanation) + '\\'])/following::td[1]/label')

TestObject to = new TestObject('newTd')

to.addProperty('xpath', ConditionType.EQUALS, xpath)

WebUI.click(to)

/*
 * 사용 중지 평가척도
 * */
'사용 중지 평가척도 이동'
WebUI.scrollToPosition(0, 0)

WebUI.delay(1)

WebUI.click(findTestObject('Object Repository/Page_Admin_Manager_Recruit_RatingScale/Page_Menu_RatingScale/a_stopList'))

WebUI.verifyTextPresent(explanation, false)

WebUI.delay(1)

WebUI.click(to)

''', 'Test Cases/Admin Site/AD_05_001_Recruit_Rating_Scale', new TestCaseBinding('Test Cases/Admin Site/AD_05_001_Recruit_Rating_Scale',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
