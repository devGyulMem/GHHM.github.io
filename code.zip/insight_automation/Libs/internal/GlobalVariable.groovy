package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object CompanySiteURL
     
    /**
     * <p></p>
     */
    public static Object AdminSiteURL
     
    /**
     * <p></p>
     */
    public static Object AdminSiteID
     
    /**
     * <p></p>
     */
    public static Object AdminSitePW
     
    /**
     * <p></p>
     */
    public static Object COMPANY_AUTHORITY_KEY
     
    /**
     * <p></p>
     */
    public static Object API_SERVICE_KEY
     
    /**
     * <p></p>
     */
    public static Object QnA_Title
     
    /**
     * <p></p>
     */
    public static Object API_ResumeSn
     
    /**
     * <p></p>
     */
    public static Object API_NoticeSn
     
    /**
     * <p></p>
     */
    public static Object API_Domain
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            CompanySiteURL = selectedVariables['CompanySiteURL']
            AdminSiteURL = selectedVariables['AdminSiteURL']
            AdminSiteID = selectedVariables['AdminSiteID']
            AdminSitePW = selectedVariables['AdminSitePW']
            COMPANY_AUTHORITY_KEY = selectedVariables['COMPANY_AUTHORITY_KEY']
            API_SERVICE_KEY = selectedVariables['API_SERVICE_KEY']
            QnA_Title = selectedVariables['QnA_Title']
            API_ResumeSn = selectedVariables['API_ResumeSn']
            API_NoticeSn = selectedVariables['API_NoticeSn']
            API_Domain = selectedVariables['API_Domain']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
