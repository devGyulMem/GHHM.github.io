import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import groovy.lang.MissingPropertyException
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\user\\AppData\\Local\\Temp\\Katalon\\Test Cases\\Company Site\\CP_02_003_Application_RegistResume_Basicinfo\\20190121_173931\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

not_run: WebUI.callTestCase(findTestCase('Company Site/CP_02_002_Application_RegistResume_Signup(New)'), [('applicantname') : '테스터'
        , ('phone1') : '010', ('phone2') : '1234', ('phone3') : '5678', ('email') : 'qatest@midasit.com', ('password') : 'wldnjstjwkrtjd!'], 
    FailureHandling.STOP_ON_FAILURE)

'지원자 영문 이름 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__englishName'), englishName)

'지원자 한문 이름 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__chineseName'), chineseName)

'지원자 생년 월일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__birthday'), birthday)

WebUI.delay(1)

'지원분야 1 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_sector_1'), selectSector1, 
    true)

'지원분야 2 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_sector_2'), selectSector2, 
    true)

'지원자 성별 남 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span_gender_male'))

'지원분야 3 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_sector_3'), selectSector3, 
    true)

'지원분야 4 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_sector_4'), selectSector4, 
    true)

'희망연봉 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__hopeSalary'), hopeSalary)

'직전연봉 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__latestSalary'), latestSalary)

'희망직급 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__hopePosition'), hopePosition)

'입사가능일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__joinPossibleDate'), joinPossibleDate)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_basicinfo/input__joinPossibleDate'), Keys.chord(Keys.TAB))

WebUI.delay(1)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_basicinfo/regionwork_y'), 1)

'지방근무 가능여부 가능 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/regionwork_y'))

'면접가능지역 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_interviewarea'), interviewarea, 
    true)

'추천인 성명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__recommender.name'), recommandName)

WebUI.delay(1)

'추천인과의 관계 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input_ _recommender.relationsh'), recommandRelationsh)

'추천인 연락처 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input_ _recommender.contact'), recommandContact)

'추천인 소속 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input_ _recommender.department'), recommendDepartment)

'추천인 비고 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__recommender.comment'), recommenderComment)

'지원경로 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_applychannel'), selectApplychannel, 
    true)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_basicinfo/select_basic_additionalinfo_singleanswer'), 
    1)

'추가질문 부가정보 추가질문 단일응답 선택 문항 단일 보기 문항 1 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_basic_additionalinfo_singleanswer'), 
    select_basic_additionalInfo_singleanswer, true)

'추가질문 부가정보 복수응답 선택 문항 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_basic_additionalinfo_multianswer'))

'복수 보기 문항 1 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/option_basic_additional_multianswer_1'))

'복수 보기 문항 2 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/option_basic_additional_multianswer_2'))

'부가정보 텍스트 입력 문항 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/textarea_basic_additionalinfo'), additionalInfo)

'부가정보 멀티텍스트 입력 문항 하위 문항 항목 1 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/textarea_basic_additionalinfo_multitext_1'), 
    additionalMultitext1)

'부가정보 멀티텍스트 입력 문항 하위 문항 항목 2 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/textarea_basic_additionalinfo_multitext_2'), 
    additionalMultitext2)

WebUI.delay(1)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_basicinfo/button_picture'), 2)

String userdir = System.getProperty('user.dir')

String filepath = userdir + '\\\\Data Files\\\\mypicture.jpg'

'사진 등록'
WebUI.uploadFile(findTestObject('Page_Company_Application_registResume_basicinfo/picture_label'), filepath)

WebUI.delay(2)

'국적 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_nationality'), nationality, 
    true)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_basicinfo/button_address'), 0)

'우편번호 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_address'))

String Step2Title = '이력서 작성 | ' + jobnoticename

WebUI.switchToWindowTitle(Step2Title)

WebUI.mouseOver(findTestObject('Page_Company_Application_registResume_basicinfo/input_address'))

'판교 검색'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input_address'), address)

WebUI.delay(1)

'검색 버튼 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button__searchaddress'))

WebUI.delay(1)

'검색결과 출력 확인'
WebUI.verifyElementPresent(findTestObject('Page_Company_Application_registResume_basicinfo/span_select_address_searchresult'), 
    1)

'검색결과 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span_select_address_searchresult'))

'상세 주소 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__address_details'), addressDetails)

WebUI.delay(1)

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button__save_address'))

WebUI.switchToWindowTitle(Step2Title)

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button__confirm_save_address'))

WebUI.delay(1)

'종교 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_religion'), religion, true)

'특기 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__specialAbility'), specialAbility)

'취미 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__hobby'), hobby)

'혈액형 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_blood'), blood, true)

'신장 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__height'), height)

'체중 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__weight'), weight)

'신체 특이사항 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input_ _physicalRemark'), physicalRemark)

'색약 여부 있음 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span__colorweakness_y'))

'적색약 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span__colorweakness_red'))

'좌시력 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__leftSight'), leftSight)

'우시력 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__rightSight'), rightSight)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_basicinfo/span_smoking_y'), 0)

'흡연여부 흡연 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span_smoking_y'))

'결혼여부 기혼 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span__marry_y'))

'형제관계 남자 형제 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__family.brotherNumber'), brotherNum)

'형제관계 여자 형제 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__family.sisterCount'), sisterCount)

'형제관계 순서 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__family.familySequence'), familySeq)

'가족관계 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select__familyrelation_1'), familyRelation1, 
    true)

WebUI.delay(1)

'가족 이름 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__familyRelation0.name'), familyRelation1Name)

'가족 연령 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__familyRelation0.age'), familyRelataion1Age)

'동거 여부 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span_familyrelation1_livetogether_y'))

WebUI.delay(1)

'가족관계 추가 버튼 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button__add_familyrelation'))

'가족관계 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select__familyrelation_2'), familyRelation2, 
    true)

WebUI.delay(1)

'가족 이름 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__familyRelation1.name'), familyRalation2Name)

'가족 연령 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__familyRelation1.age'), familyRalation2Age)

'동거 여부 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span_familyrelation2_livetogether_y'))

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_basicinfo/span_handicap_y'), 1)

'장애여부 대상 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span_handicap_y'))

WebUI.delay(1)

'장애 등급 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_handicapgrade'), handicapGrade, 
    true)

'장애 유형 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_handicapcode'), handicapCode, 
    true)

'보훈여부 대상 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span_patriot_y'))

WebUI.delay(1)

'보훈번호 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__patriot.patriotNumber'), patriotNumber)

'보훈 관계 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__patriot.relationship'), patriotRelationship)

'보훈 비율 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_patriotpercent'), patriotPercent, 
    true)

'저소득층 여부 대상 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span__lowincome_y'))

WebUI.delay(1)

'차상위계층 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span__lowerincomegroup'))

'저소득층 관계 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__lowIncomeRelationship'), lowIncomeRelationship)

'주거형태 월세 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span_resedence_monthlyrent'))

'좌우명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__motto'), motto)

'병역구분 군필 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/span_military_Fulfilled'))

WebUI.delay(1)

'군별 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_militaryBranchCode'), militaryBranchCode, 
    true)

'병과 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__military.militaryRole'), militaryRole)

'계급 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_militaryPositionCode'), 
    militaryPositionCode, true)

'복무기간 시작 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__military.militaryStartD'), militaryStartDate)

'복무기간 끝 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/input__military.militaryEndDat'), militaryEndDate)

'제대구분 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_militaryDischargeCode'), 
    militaryDischargeCode, true)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_basicinfo/select_personal_additionalinfo_singleanswer'), 
    0)

'인적사항 단일 선택 문항  보기 문항 3 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_basicinfo/select_personal_additionalinfo_singleanswer'), 
    personalAdditionalInfo, true)

'인적사항 복수응답 선택 문항 답변 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_personal_additionalinfo_multianswer'))

'인적사항 복수응답 보기 문항 1 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/option_personal_additional_multianswer_1'))

'인적사항 텍스트 입력 문항 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/textarea_personal_additionalinfo'), personalAdditionalInfo)

'인적사항 멀티텍스트 입력 문항 하위 문항 1 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/textarea_personal_additionalinfo_multitext_1'), 
    personalAdditionalInfo_multitext1)

'인적사항 멀티텍스트 입력 문항 하위 문항 2 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_basicinfo/textarea_personal_additionalinfo_multitext_2'), 
    personalAdditionalInfo_multitext2)

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_save_temp'))

WebUI.delay(1)

WebUI.switchToWindowTitle(Step2Title)

WebUI.focus(findTestObject('Page_Company_Application_registResume_basicinfo/button_save_temp_y'))

'임시저장 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_save_temp_y'))

WebUI.delay(1)

WebUI.verifyElementPresent(findTestObject('Page_Company_Application_registResume_basicinfo/button_confirm_save_temp'), 1)

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_confirm_save_temp'))

WebUI.delay(1)

'다음 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button__Next'))

WebUI.switchToWindowTitle(Step2Title)

WebUI.switchToWindowTitle(Step2Title)

WebUI.focus(findTestObject('Page_Company_Application_registResume_basicinfo/button_next_y'))

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_next_y'))

WebUI.delay(1)

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_next_confirm'))

''', 'Test Cases/Company Site/CP_02_003_Application_RegistResume_Basicinfo', new TestCaseBinding('Test Cases/Company Site/CP_02_003_Application_RegistResume_Basicinfo',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
