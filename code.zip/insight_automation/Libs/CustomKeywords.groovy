
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String

import java.util.Date


def static "userdefinepkg.customElementHandling.clickUsingJS"(
    	TestObject to	
     , 	int timeout	) {
    (new userdefinepkg.customElementHandling()).clickUsingJS(
        	to
         , 	timeout)
}

def static "userdefinepkg.customElementHandling.setValueUsingJS"(
    	TestObject to	
     , 	String txt	
     , 	int timeout	) {
    (new userdefinepkg.customElementHandling()).setValueUsingJS(
        	to
         , 	txt
         , 	timeout)
}

def static "userdefinepkg.dynamicTestobject.getMyTestObject"(
    	String selectorType	
     , 	String selectorValue	) {
    (new userdefinepkg.dynamicTestobject()).getMyTestObject(
        	selectorType
         , 	selectorValue)
}

def static "userdefinepkg.File_Handle.Open_File"(
    	String FilePath	) {
    (new userdefinepkg.File_Handle()).Open_File(
        	FilePath)
}

def static "userdefinepkg.File_Handle.Delete_File"(
    	String FilePath	) {
    (new userdefinepkg.File_Handle()).Delete_File(
        	FilePath)
}

def static "userdefinepkg.killchromeprocess.killProcess"() {
    (new userdefinepkg.killchromeprocess()).killProcess()
}

def static "userdefinepkg.customFileupload.uploadFile"(
    	TestObject to	
     , 	String inputfilePath	) {
    (new userdefinepkg.customFileupload()).uploadFile(
        	to
         , 	inputfilePath)
}

def static "userdefinepkg.timeExpression.getDate"() {
    (new userdefinepkg.timeExpression()).getDate()
}

def static "userdefinepkg.timeExpression.getHour"(
    	Date present	) {
    (new userdefinepkg.timeExpression()).getHour(
        	present)
}

def static "userdefinepkg.timeExpression.getMinute"(
    	Date present	) {
    (new userdefinepkg.timeExpression()).getMinute(
        	present)
}

def static "userdefinepkg.timeExpression.getYMD"(
    	Date present	) {
    (new userdefinepkg.timeExpression()).getYMD(
        	present)
}

def static "userdefinepkg.timeExpression.getYMD_dot"(
    	Date present	) {
    (new userdefinepkg.timeExpression()).getYMD_dot(
        	present)
}

def static "userdefinepkg.timeExpression.getYMDHM"(
    	Date present	) {
    (new userdefinepkg.timeExpression()).getYMDHM(
        	present)
}

def static "userdefinepkg.timeExpression.getYMDHMS"(
    	Date present	) {
    (new userdefinepkg.timeExpression()).getYMDHMS(
        	present)
}

def static "userdefinepkg.timeExpression.addAMonth"(
    	Date present	) {
    (new userdefinepkg.timeExpression()).addAMonth(
        	present)
}

def static "userdefinepkg.timeExpression.addADay"(
    	Date present	) {
    (new userdefinepkg.timeExpression()).addADay(
        	present)
}

def static "userdefinepkg.timeExpression.addNMinute"(
    	Date present	
     , 	int n	) {
    (new userdefinepkg.timeExpression()).addNMinute(
        	present
         , 	n)
}

def static "userdefinepkg.timeExpression.addNHour"(
    	Date present	
     , 	int n	) {
    (new userdefinepkg.timeExpression()).addNHour(
        	present
         , 	n)
}

def static "userdefinepkg.timeExpression.addNDay"(
    	Date present	
     , 	int n	) {
    (new userdefinepkg.timeExpression()).addNDay(
        	present
         , 	n)
}

def static "userdefinepkg.timeExpression.addNMonth"(
    	Date present	
     , 	int n	) {
    (new userdefinepkg.timeExpression()).addNMonth(
        	present
         , 	n)
}

def static "userdefinepkg.timeExpression.addNYear"(
    	Date present	
     , 	int n	) {
    (new userdefinepkg.timeExpression()).addNYear(
        	present
         , 	n)
}

def static "userdefinepkg.timeExpression.getCurrentTime"() {
    (new userdefinepkg.timeExpression()).getCurrentTime()
}

def static "userdefinepkg.timeExpression.getHMSCurrentTime"() {
    (new userdefinepkg.timeExpression()).getHMSCurrentTime()
}

def static "userdefinepkg.forcestop.FORCESTOP"() {
    (new userdefinepkg.forcestop()).FORCESTOP()
}
