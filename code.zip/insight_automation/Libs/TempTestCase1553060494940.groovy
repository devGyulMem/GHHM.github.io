import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\user\\AppData\\Local\\Temp\\Katalon\\Test Cases\\Admin Site\\AD_98_001_Admin_DashBoard_ApplicantNotice\\20190320_144134\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import groovy.time.TimeCategory as TimeCategory
import internal.GlobalVariable as GlobalVariable

/**
 * Global Variable
 */
not_run: WebUI.callTestCase(findTestCase('Admin Site/AD_01_002_Admin_Login(Valid Account)'), [('admin_ID') : GlobalVariable.AdminSiteID
        , ('admin_password') : GlobalVariable.AdminSitePW], FailureHandling.OPTIONAL)

not_run: String userdir = System.getProperty('user.dir')

not_run: String filepath = userdir + '\\\\Data Files\\\\flower.jpg'

not_run: String filepath2 = userdir + '\\\\Data Files\\\\mypicture.jpg'

'오늘 시간 구하기'
not_run: use(TimeCategory, { 
        // 오늘
        today = new Date()

        // 5일 후 
        afterfivedays = (today + 5.days)
    })

not_run: String Admin_Dashboard_URL = GlobalVariable.AdminSiteURL + '/mrs2/manager/dashboard'

not_run: WebUI.navigateToUrl('https://testsvc-company-admin-recruiter-co-kr.midasweb.net/mrs2/manager/bbs/cus/appsite/notice/list')

'Admin 대시보드 페이지로 이동'
not_run: WebUI.navigateToUrl(Admin_Dashboard_URL)

not_run: WebUI.delay(1)

'게시판 관리 클릭'
not_run: WebUI.click(findTestObject('Page_Admin_DashBoard_ApplicantNotice/select_boardManage'))

'지원자 공지사항 클릭'
WebUI.click(findTestObject('Page_Admin_DashBoard_ApplicantNotice/select_applicantNotice'))

not_run: String newStr = GlobalVariable.AdminSiteURL + '/mrs2/manager/bbs/cus/appsite/notice/write'

not_run: WebUI.navigateToUrl(newStr)

not_run: WebUI.delay(1)

'wait 글쓰기 버튼 클릭'
not_run: if (WebUI.waitForElementClickable(findTestObject('Page_Admin_DashBoard_ApplicantNotice/button_write'), 20, FailureHandling.OPTIONAL)) {
    '글쓰기 버튼 클릭'
}

not_run: WebUI.click(findTestObject('Page_Admin_DashBoard_ApplicantNotice/button_write'))

'공지여부 클릭'
not_run: WebUI.click(findTestObject('Page_Admin_DashBoard_ApplicantNotice/checkbox_isShowNotice'))

'제목 입력'
not_run: WebUI.setText(findTestObject('Page_Admin_DashBoard_ApplicantNotice/input_title'), '지원자 공지사항 등록 테스트')

'기본이미지 체크박스 클릭'
not_run: WebUI.click(findTestObject('Page_Admin_DashBoard_ApplicantNotice/checkbox_useDefaultImage'))

'리스트이미지 업로드'
not_run: WebUI.uploadFile(findTestObject('Object Repository/Page_Admin_DashBoard_ApplicantNotice/input_file_listImageName'), 
    filepath)

'첨부 파일 업로드'
not_run: WebUI.uploadFile(findTestObject('Page_Admin_DashBoard_ApplicantNotice/input_file_attachFileList'), filepath)

'첨부 추가(+) 버튼 클릭'
not_run: WebUI.click(findTestObject('Page_Admin_DashBoard_ApplicantNotice/button_add_attachFileList'))

'첨부 - 2번째 파일 업로드'
not_run: WebUI.uploadFile(findTestObject('Page_Admin_DashBoard_ApplicantNotice/input_file_attachFileList_2'), filepath2)

'게시물 노출 설정 - 자동설정 라디오 버튼 클릭'
not_run: WebUI.click(findTestObject('Page_Admin_DashBoard_ApplicantNotice/radio_isPeriodPost'))

'시작 일자 -오늘 날짜 입력'
not_run: WebUI.setText(findTestObject('Page_Admin_DashBoard_ApplicantNotice/input_postStartYmd'), today.format('yyyy.MM.dd'))

'시작 일자 - 시간 입력'
not_run: WebUI.setText(findTestObject('Object Repository/Page_Admin_DashBoard_ApplicantNotice/input_start_hh'), '12')

'시작 일자 - 분 입력'
not_run: WebUI.setText(findTestObject('Object Repository/Page_Admin_DashBoard_ApplicantNotice/input_start_mm'), '10')

'종료 일자 - 5일 후 날짜 입력'
not_run: WebUI.setText(findTestObject('Page_Admin_DashBoard_ApplicantNotice/input_postEndYmd'), afterfivedays.format('yyyy.MM.dd'))

'종료 일자 - 시간 입력'
not_run: WebUI.setText(findTestObject('Object Repository/Page_Admin_DashBoard_ApplicantNotice/input_close_hh'), '18')

'종료 일자 - 분 입력'
not_run: WebUI.setText(findTestObject('Object Repository/Page_Admin_DashBoard_ApplicantNotice/input_start_mm'), '10')

'빈 공간 클릭'
not_run: WebUI.click(findTestObject('Page_Admin_DashBoard_ApplicantNotice/div_emptySpace'))

'내용 입력'
not_run: WebUI.setText(findTestObject('Page_Admin_DashBoard_ApplicantNotice/textarea_content'), '<p style="">지원자 공지사항&nbsp;</p><p style=""><br></p><p style="">내용 입력 테스트</p>')

'취소 버튼 클릭'
not_run: WebUI.rightClick(findTestObject('Page_Admin_DashBoard_ApplicantNotice/button_cancel'))

'저장하기 버튼 클릭'
not_run: WebUI.click(findTestObject('Page_Admin_DashBoard_ApplicantNotice/button_save'))

''', 'Test Cases/Admin Site/AD_98_001_Admin_DashBoard_ApplicantNotice', new TestCaseBinding('Test Cases/Admin Site/AD_98_001_Admin_DashBoard_ApplicantNotice',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
