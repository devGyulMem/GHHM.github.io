import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\user\\AppData\\Local\\Temp\\Katalon\\Test Cases\\Company Site\\CP_02_005_Application_RegistResume_eduinfo-2\\20190315_152936\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

not_run: WebUI.callTestCase(findTestCase('Company Site/CP_02_003_Application_RegistResume_eduinfo'), [('jobnoticename') : '[QA] 회귀테스트용 공고'], 
    FailureHandling.STOP_ON_FAILURE)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_paper_y'), 1)

//WebUI.takeScreenshot('D:\\\\222222.png')
'논문 첨부 예 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_paper_y'))

WebUI.delay(1)

'논문 학위 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_paper_degreetype'))

WebUI.delay(1)

'논문 타이틀 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__paper0.title'), paper0Title)

'논문 요약 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/textarea_paper0.contents'), '박사 논문 내용 요약')

filepath = (userdir + '\\\\Data Files\\\\논문.docx')

'논문 파일 첨부'
WebUI.uploadFile(findTestObject('Page_Company_Application_registResume_eduinfo/Uploadfile_Paper'), filepath)

WebUI.delay(1)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_Research_Achievements_y'), 1)

'연구실적 자격 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_Research_Achievements_y'))

WebUI.delay(1)

'연구논문 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_Research_pager_y'))

WebUI.delay(1)

'연구실적 게재구분 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_Researchpaper_publishcode'))

WebUI.delay(1)

'연구논문 논문구분 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_Researchpaper_papertype'), 
    researchPaper_papertype, true)

'연구논문 논문제목 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPaper0.title'), researchPaper0Title)

'연구논문 게재지명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPaper0.journalN'), researchPaper0JournalN)

'연구논문 게재일자 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPaper0.publishD'), researchPaper0PublishD)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPaper0.publishD'), Keys.chord(
        Keys.TAB))

'연구논문 저자순위 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPaper0.ranking'), 'researchPaper0Ranking')

'연구논문 연구 참여자 수 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPaper0.headcoun'), researchPaper0Headcount)

'연구논문 역할 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_Researchpaper_role'), researchPaperRole, 
    true)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_researchpresent_y'), 1)

'학술논문 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_researchpresent_y'))

WebUI.delay(1)

'학술논문 발표구분 국제 학술회의 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/Researchpresent_presentcode'))

WebUI.delay(1)

'학술논문 대회명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPresent0.confer'), researchPresent0Confer)

'학술논문 주최기관 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPresent0.organi'), researchPresent0Origani)

'학술논문 발표제목 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPresent0.title'), researchPresent0Title)

'학술논문 발표일자 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPresent0.presen'), researchPresent0PresentD)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPresent0.presen'), Keys.chord(
        Keys.TAB))

'학술논문 저자순위 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPresent0.rankin'), researchPresent0Ranking)

'학술논문 참여자수 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchPresent0.headco'), researchPresent0Headcount)

'학술논문 역할 입력'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_Researchpresent_role'), researchPresentRole, 
    true)

'지식재산권 실적 예 선택'
WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_ipr_publish_y'), 1)

WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_ipr_publish_y'))

WebUI.delay(1)

'지식재산권 상태구분 출원 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_ipr_statuscode'))

WebUI.delay(1)

'지식재산권 분류구분 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_ipr_type'), iprType, true)

'지식재산권 명칭 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchIPR0.iprName'), researchIPR0iprName)

'지식재산권 출원국가 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_ipr_country'), iprCountry, 
    true)

'지식재산권 출원번호 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchIPR0.registNumb'), researchIPR0registNumb)

'지식재산권 등록일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchIPR0.registDate'), researchIPR0RegistDate)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchIPR0.registDate'), Keys.chord(
        Keys.TAB))

'지식재산권 발명자순위 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchIPR0.ranking'), researchIPR0Ranking)

'지식재산권 참여자수 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchIPR0.headcount'), researchIPR0Headcount)

'지식재산권 역할 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_ipr_role'), iprRole, true)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_research_y'), 1)

'연구과제 참여 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_research_y'))

WebUI.delay(1)

'연구과제 과제명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchInvolve0.title'), researchInvolve0Title)

WebUI.delay(1)

'연구과제 발주기관명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchInvolve0.organi'), researchInvolve0Origani)

'연구과제 시작일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchInvolve0.startD'), researchInvolve0StartD)

'연구과제 종료일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchInvolve0.endDat'), researchInvolve0EndD)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchInvolve0.endDat'), Keys.chord(
        Keys.TAB))

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_book_y'), 1)

'저서 실적 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_book_y'))

WebUI.delay(1)

'저서 분류구분 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_book_type'), bookType, true)

WebUI.delay(1)

'저서 공동집필여부 공동 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_book_writercode'))

'저서 저서명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchWriting0.title'), researchingWriting0Title)

'저서 발행일자 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchWriting0.publis'), researchingWriting0PublishD)

'저서 발행기관 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchWriting0.organi'), researchingWriting0Organi)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchWriting0.publis'), Keys.chord(
        Keys.TAB))

'저서 저자순위 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchWriting0.rankin'), researchingWriting0Ranking)

'저서 참여자 수 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__researchWriting0.headco'), researchingWriting0HeadCount)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/select_career_code'), 1)

''', 'Test Cases/Company Site/CP_02_005_Application_RegistResume_eduinfo-2', new TestCaseBinding('Test Cases/Company Site/CP_02_005_Application_RegistResume_eduinfo-2',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
