import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import groovy.lang.MissingPropertyException
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import internal.GlobalVariable as GlobalVariable

Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/002_RegistResume')

suiteProperties.put('name', '002_RegistResume')

suiteProperties.put('description', '\uC9C0\uC6D0\uC790\uAC00 \uCC44\uC6A9\uC0AC\uC774\uD2B8\uC5D0 \uC811\uC18D\uD55C \uD6C4 \uCC44\uC6A9\uACF5\uACE0\uB97C \uC120\uD0DD\uD558\uACE0 \uC774\uB825\uC11C\uB97C \uC791\uC131\uD55C\uB2E4.')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())



RunConfiguration.setExecutionSettingFile("D:\\insight_automation\\Reports\\002_RegistResume\\20190121_175607\\execution.properties")

TestCaseMain.beforeStart()

TestCaseMain.startTestSuite('Test Suites/002_RegistResume', suiteProperties, [new TestCaseBinding('Test Cases/Company Site/CP_02_002_Application_RegistResume_Signup(New)', 'Test Cases/Company Site/CP_02_002_Application_RegistResume_Signup(New)',  [ 'applicantname' : '\uD14C\uC2A4\uD130' , 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' , 'phone1' : '010' , 'phone2' : '1234' , 'phone3' : '5674' , 'email' : 'qatest@midasit.com' , 'password' : 'wldnjstjwkrtjd!' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_003_Application_RegistResume_Basicinfo', 'Test Cases/Company Site/CP_02_003_Application_RegistResume_Basicinfo',  [ 'joinPossibleDate' : '2019.12.13' , 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' , 'latestSalary' : '5500' , 'englishName' : 'Hyemi Kim' , 'chineseName' : '\u91D1\u60E0\u7F8E' , 'interviewarea' : '\uBD84\uB2F9' , 'hopeSalary' : '5000' , 'selectSector1' : '\uC2E0\uC785' , 'selectSector2' : '\uC6F9\uC194\uB8E8\uC158 \uAC1C\uBC1C\uBD84\uC57C' , 'selectSector3' : '\uACBD\uC601/\uC0AC\uBB34' , 'hopePosition' : '\uC2E0\uC785' , 'selectSector4' : '\uC804\uACF5\uBB34\uAD00' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_004_Application_RegistResume_eduinfo', 'Test Cases/Company Site/CP_02_004_Application_RegistResume_eduinfo',  [ 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_005_Application_RegistResume_Licenseinfo', 'Test Cases/Company Site/CP_02_005_Application_RegistResume_Licenseinfo',  [ 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_006_Application_RegistResume_Coverletter', 'Test Cases/Company Site/CP_02_006_Application_RegistResume_Coverletter',  [ 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_007_Application_RegistResume_lastsubmit', 'Test Cases/Company Site/CP_02_007_Application_RegistResume_lastsubmit',  [ 'applicantname' : '\uD14C\uC2A4\uD130' , 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' ,  ]), new TestCaseBinding('Test Cases/ETC/Kill_Process', 'Test Cases/ETC/Kill_Process',  null)])
