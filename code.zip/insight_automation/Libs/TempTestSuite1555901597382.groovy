import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import internal.GlobalVariable as GlobalVariable

Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/008_RegistInterview')

suiteProperties.put('name', '008_RegistInterview')

suiteProperties.put('description', '\uBA74\uC811\uC804\uD615\uB4F1\uB85D')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())



RunConfiguration.setExecutionSettingFile("D:\\insight_automation\\Reports\\008_RegistInterview\\20190422_115317\\execution.properties")

TestCaseMain.beforeStart()

TestCaseMain.startTestSuite('Test Suites/008_RegistInterview', suiteProperties, [new TestCaseBinding('Test Cases/Admin Site/AD_08_001_Regist_InterviewScreening_Step1', 'Test Cases/Admin Site/AD_08_001_Regist_InterviewScreening_Step1',  null), new TestCaseBinding('Test Cases/Admin Site/AD_08_001_Regist_InterviewScreening_Step3', 'Test Cases/Admin Site/AD_08_001_Regist_InterviewScreening_Step3',  null), new TestCaseBinding('Test Cases/Admin Site/AD_08_001_Regist_InterviewScreening_Step2', 'Test Cases/Admin Site/AD_08_001_Regist_InterviewScreening_Step2',  null), new TestCaseBinding('Test Cases/Admin Site/AD_08_001_Regist_InterviewScreening_Step4', 'Test Cases/Admin Site/AD_08_001_Regist_InterviewScreening_Step4',  null), new TestCaseBinding('Test Cases/ETC/Close_Browser', 'Test Cases/ETC/Close_Browser',  null), new TestCaseBinding('Test Cases/ETC/Kill_Process', 'Test Cases/ETC/Kill_Process',  null)])
