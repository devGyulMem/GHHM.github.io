import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\user\\AppData\\Local\\Temp\\Katalon\\Test Cases\\Admin Site\\AD_98_006_Admin_DashBoard_Popup\\20190408_175912\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

not_run: WebUI.callTestCase(findTestCase('Admin Site/AD_01_002_Admin_Login(Valid Account)'), [('admin_ID') : GlobalVariable.AdminSiteID
        , ('admin_password') : GlobalVariable.AdminSitePW], FailureHandling.OPTIONAL)

'insight 2.0 으로 접속'
not_run: CustomKeywords.'userdefinepkg.customElementHandling.clickUsingJS'(findTestObject('Page_Admin_DashBoard_ApplicantNotice/select_Insight_2'), 
    30)

not_run: WebUI.delay(1)

'카테고리 선택 게시판 관리 > 평가자 공지사항'
not_run: WebUI.callTestCase(findTestCase('Admin Site/AD_98_000_Admin_DashBaord_SelectMenu'), [('selectMenu') : 'Popup'], 
    FailureHandling.OPTIONAL)

not_run: WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/button_new'))

not_run: WebUI.setText(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/input_title'), '팝업창 제목')

'수동설정'
not_run: WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/radio_isPeriodPost'))

'진행'
not_run: WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/radio_postStateCode_progress'))

'지원자'
not_run: WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/radio_applicant'))

'평가자'
not_run: WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/radio_eval'))

'내용 작성방식 > 이미지 업로드'
not_run: WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/input_useImageUpload'))

//업로드 이미지 경로 설정
String userdir = System.getProperty('user.dir')

String filepath = userdir + '\\\\Data Files\\\\white_flower.jpg'

'이미지 업로드'
WebUI.uploadFile(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/input_ _imageFile'), filepath)

'이미지 클릭시 링크 걸기'
WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/input_enableLinkUrl'))

WebUI.setText(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/input_imageLinkURL'), 'www.naver.com')

'팝업 노출 위치 X좌표'
WebUI.setText(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/input_positionX'), 75)

'팝업 노출 위치 Y좌표'
WebUI.setText(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/input_positionY'), 95)

'등록'
WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/button_register'))

'등록 확인'
WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/button_register_confirm'))

'확인'
WebUI.click(findTestObject('Object Repository/Page_Admin_DashBoard_Popup/button_confirm'))

''', 'Test Cases/Admin Site/AD_98_006_Admin_DashBoard_Popup', new TestCaseBinding('Test Cases/Admin Site/AD_98_006_Admin_DashBoard_Popup',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
