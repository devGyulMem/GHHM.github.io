import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\user\\AppData\\Local\\Temp\\Katalon\\Test Cases\\ETC\\test\\20190614_151457\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

not_run: WebUI.openBrowser('')

not_run: WebUI.maximizeWindow()

'다음 버튼 클릭'
WebUI.click(findTestObject('Page_Admin_Manager_Regist_RecruitNotice_Step3/button_Next'))

WebUI.switchToWindowTitle('채용공고관리 | Insight')

WebUI.click(findTestObject('Page_Admin_Manager_Regist_RecruitNotice_Step3/button_Next_yes'))

WebUI.switchToWindowTitle('채용공고관리 | Insight')

WebUI.click(findTestObject('Page_Admin_Manager_Regist_RecruitNotice_Step3/button_Confirm'))

'다음 클릭'
WebUI.click(findTestObject('Page_Admin_Manager_Regist_RecruitNotice_Step4/button_Next'))

WebUI.switchToWindowTitle('채용공고관리 | Insight')

WebUI.click(findTestObject('Page_Admin_Manager_Regist_RecruitNotice_Step4/button_Next_yes'))

WebUI.switchToWindowTitle('채용공고관리 | Insight')

WebUI.click(findTestObject('Page_Admin_Manager_Regist_RecruitNotice_Step4/button_Confirm'))

''', 'Test Cases/ETC/test', new TestCaseBinding('Test Cases/ETC/test',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
