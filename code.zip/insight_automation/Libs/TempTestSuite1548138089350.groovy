import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import groovy.lang.MissingPropertyException
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import internal.GlobalVariable as GlobalVariable

Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/002_RegistResume')

suiteProperties.put('name', '002_RegistResume')

suiteProperties.put('description', '\uC9C0\uC6D0\uC790\uAC00 \uCC44\uC6A9\uC0AC\uC774\uD2B8\uC5D0 \uC811\uC18D\uD55C \uD6C4 \uCC44\uC6A9\uACF5\uACE0\uB97C \uC120\uD0DD\uD558\uACE0 \uC774\uB825\uC11C\uB97C \uC791\uC131\uD55C\uB2E4.')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())



RunConfiguration.setExecutionSettingFile("D:\\insight_automation\\Reports\\002_RegistResume\\20190122_152129\\execution.properties")

TestCaseMain.beforeStart()

TestCaseMain.startTestSuite('Test Suites/002_RegistResume', suiteProperties, [new TestCaseBinding('Test Cases/Company Site/CP_02_002_Application_RegistResume_Signup(New)', 'Test Cases/Company Site/CP_02_002_Application_RegistResume_Signup(New)',  [ 'applicantname' : '\uD14C\uC2A4\uD130' , 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' , 'phone1' : '010' , 'phone2' : '1234' , 'phone3' : '5674' , 'email' : 'qatest@midasit.com' , 'password' : 'wldnjstjwkrtjd!' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_003_Application_RegistResume_Basicinfo', 'Test Cases/Company Site/CP_02_003_Application_RegistResume_Basicinfo',  [ 'joinPossibleDate' : '2019.12.13' , 'additionalMultitext2' : '\uBA40\uD2F0\uD14D\uC2A4\uD2B8 \uC785\uB825 \uCD5C\uC18C 50\uC790  \uBA40\uD2F0\uD14D\uC2A4\uD2B8 \uC785\uB825 \uCD5C\uC18C 50\uC790  \uBA40\uD2F0\uD14D\uC2A4\uD2B8 \uC785\uB825 \uCD5C\uC18C 50\uC790  !@#$%^&*() ' , 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' , 'recommenderComment' : '\uBE44\uACE0' , 'colorweaknessRed' : '' , 'militaryRole' : '\uCDE8\uC0AC\uBCD1' , 'weight' : '70' , 'selectSector3' : '\uACBD\uC601/\uC0AC\uBB34' , 'recommandName' : '\uCD94\uCC9C\uC778' , 'leftSight' : '1.2' , 'militaryBranchCode' : '\uC721\uAD70' , 'address' : '\uD310\uAD50' , 'colorweaknessY' : '' , 'handicapCode' : '\uC2DC\uAC01\uC7A5\uC560' , 'nationality' : '\uB0A8\uADF9' , 'chineseName' : '\u91D1\u60E0\u7F8E' , 'birthday' : '1996.01.12' , 'blood' : 'AB' , 'personalAdditionalInfo' : '\uC778\uC801\uC0AC\uD56D \uD14D\uC2A4\uD2B8 \uC785\uB825 \uBB38\uD56D \uCD5C\uC18C 20\uC790 \uCD5C\uB300 20\uC790' , 'additionalMultitext1' : '\uBA40\uD2F0\uD14D\uC2A4\uD2B8 \uC785\uB825 \uCD5C\uC18C 50\uC790  \uBA40\uD2F0\uD14D\uC2A4\uD2B8 \uC785\uB825 \uCD5C\uC18C 50\uC790  \uBA40\uD2F0\uD14D\uC2A4\uD2B8 \uC785\uB825 \uCD5C\uC18C 50\uC790  !@#$%^&*() ' , 'militaryPositionCode' : '\uBCD1\uC7A5' , 'patriotNumber' : '\uBCF4\uD6C8\uBC88\uD638123' , 'rightSight' : '1.1' , 'personalAdditionalInfo_multitext1' : '\uC778\uC801\uC0AC\uD56D \uBA40\uD2F0\uD14D\uC2A4\uD2B8 \uC785\uB825\uBB38\uD56D \uCCAB\uBC88\uC9F8  !@#$%^&*( 1234567890' , 'hobby' : '\uC9C0\uC6D0\uC790 \uCDE8\uBBF8\uC0AC\uD56D' , 'selectSector2' : '\uC6F9\uC194\uB8E8\uC158 \uAC1C\uBC1C\uBD84\uC57C' , 'additionalInfo' : '\uCD94\uAC00\uC815\uBCF4 \uD14D\uC2A4\uD2B8 \uC785\uB825' , 'familyRelation1' : '\uBD80' , 'interviewarea' : '\uBD84\uB2F9' , 'physicalRemark' : '\uC2E0\uCCB4 \uD2B9\uC774\uC0AC\uD56D \uC5C6\uC74C' , 'hopePosition' : '\uC2E0\uC785' , 'latestSalary' : '5500' , 'motto' : '\uB124 \uBA4B\uB300\uB85C \uD574\uB77C' , 'familyRelation1Name' : '\uC544\uBC84\uC9C0' , 'lowIncomeRelationship' : '\uBAA8' , 'personalAdditionalInfo_multitext2' : '\uC778\uC801\uC0AC\uD56D \uBA40\uD2F0\uD14D\uC2A4\uD2B8 \uC785\uB825\uBB38\uD56D \uB450\uBC88\uC9F8  !@#$%^&*( 1234567890' , 'selectSector1' : '\uC2E0\uC785' , 'recommandContact' : '11122223333' , 'familyRalation2Name' : '\uC5B4\uBA38\uB2C8' , 'additionalInfo_singleAnswer' : '\uB2E8\uC77C \uBCF4\uAE30 \uBB38\uD56D 1' , 'familyRelation2' : '\uBAA8' , 'militaryDischargeCode' : '\uB9CC\uAE30\uC81C\uB300' , 'hopeSalary' : '5000' , 'specialAbility' : '\uC9C0\uC6D0\uC790 \uD2B9\uC774\uC0AC\uD56D' , 'patriotPercent' : '10%' , 'selectApplychannel' : '\uB0B4\uBD80\uCD94\uCC9C' , 'militaryEndDate' : '2014.11' , 'familySeq' : '2' , 'recommandRelationsh' : '\uC9C1\uC7A5\uB3D9\uB8CC' , 'religion' : '\uBB34\uAD50' , 'englishName' : 'Hyemi Kim' , 'recommendDepartment' : '\uB9C8\uC774\uB2E4\uC2A4\uC544\uC774\uD2F0' , 'brotherNum' : '1' , 'addressDetails' : '\uC0C1\uC138\uC8FC\uC18C123' , 'familyRalation2Age' : '61' , 'militaryStartDate' : '2012.11' , 'selectSector4' : '\uC804\uACF5\uBB34\uAD00' , 'familyRelataion1Age' : '63' , 'sisterCount' : '1' , 'handicapGrade' : '5\uAE09' , 'height' : '180' , 'patriotRelationship' : '\uBD80' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_004_Application_RegistResume_eduinfo', 'Test Cases/Company Site/CP_02_004_Application_RegistResume_eduinfo',  [ 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_005_Application_RegistResume_Licenseinfo', 'Test Cases/Company Site/CP_02_005_Application_RegistResume_Licenseinfo',  [ 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_006_Application_RegistResume_Coverletter', 'Test Cases/Company Site/CP_02_006_Application_RegistResume_Coverletter',  [ 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' ,  ]), new TestCaseBinding('Test Cases/Company Site/CP_02_007_Application_RegistResume_lastsubmit', 'Test Cases/Company Site/CP_02_007_Application_RegistResume_lastsubmit',  [ 'applicantname' : '\uD14C\uC2A4\uD130' , 'jobnoticename' : '[QA] \uD68C\uADC0\uD14C\uC2A4\uD2B8\uC6A9 \uACF5\uACE0' ,  ])])
