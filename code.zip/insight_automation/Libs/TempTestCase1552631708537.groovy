import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\user\\AppData\\Local\\Temp\\Katalon\\Test Cases\\Company Site\\CP_02_007_Application_RegistResume_eduinfo-4\\20190315_153508\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_school_edu_y'), 1)

'NCS 학교교육 과목 이수 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_school_edu_y'))

WebUI.delay(1)

'NCS 학교교육 능력단위 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/button_NCS_school_ability'))

WebUI.delay(1)

'NCS 학교교육 능력단위 코드 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_ability_1'))

WebUI.delay(1)

'NCS 학교교육 과목명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsAcademyEdu0.credits'), ncsAcademyEdu0Credits)

'NCS 학교교육 이수기간 시작일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsAcademyEdu0.startDat'), ncsAcademyEdu0StartDate)

'NCS 학교교육 이수시간 종료일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsAcademyEdu0.endDate'), ncsAcademyEdu0EndDate)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsAcademyEdu0.endDate'), Keys.chord(
        Keys.TAB))

'NCS 학교교육 주요내용 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsAcademyEdu0.contents'), ncsAcademyEdu0Contents)

'NCS 학교교육 이수학점 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsAcademyEdu0.credit'), ncsAca0demyEdu0Credit)

'NCS 학교교육 학점 평점 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsAcademyEdu0.score'), ncsAcademyEdu0Score)

'NCS 학교교육 학점 만점기준 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_NCS_school_perfectscore'), 
    ncsAcademyEdu0PerfectScore, true)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_job_y'), 1)

'NCS 직업교육 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_job_y'))

WebUI.delay(1)

'NCS 직업교육 능력단위 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/button_NCS_job_ability'))

WebUI.delay(1)

'NCS 직업교육 능력단위 코드 선택\\r\\n'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_ability_2'))

'NCS 직업교육 능력단위 코드 선택\\r\\n'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_ability_3'))

WebUI.delay(1)

'NCS 직업교육 과정명 입력\\r\\n'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsJobEdu0.credits'), ncsJobEdu0Credits)

'NCS 직업교육 이수기간 시작일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsJobEdu0.startDate'), ncsJobEdu0StartDate)

'NCS 직업교육 이수기간 종료일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsJobEdu0.endDate'), ncsJobEdu0EndDate)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsJobEdu0.endDate'), Keys.chord(Keys.TAB))

'NCS 직업교육 주요내용 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsJobEdu0.contents'), ncsJobEdu0Contents)

'NCS 직업교육 교육기관 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsJobEdu0.organization'), ncsJobEdu0Organization)

'NCS 직업교육 교육시간 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsJobEdu0.time'), ncsJobEdu0Time)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_career_y'), 1)

'NCS 경력사항 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_career_y'))

WebUI.delay(1)

'NCS 경력사항 능력단위 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/button_NCS_career_ability'))

WebUI.delay(1)

'NCS 경력사항 능력단위 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_ability_4'))

WebUI.delay(1)

'NCS 경력사항 고용형태 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_NCS_career_code'), ncsCareerCode, 
    true)

'NCS 경력사항 근무기간 시작일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsCareer0.startDate'), ncsCareer0StartDate)

'NCS 경력사항 근무기간 종료일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsCareer0.endDate'), ncsCareer0EndDate)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsCareer0.endDate'), Keys.chord(Keys.TAB))

'NCS 경력사항 회사명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsCareer0.company'), ncsCareer0Company)

'NCS 경력사항 부서명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsCareer0.department'), ncsCareer0Department)

'NCS 경력사항 직급 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsCareer0.position'), ncsCareer0Position)

'NCS 경력사항 담당업무 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsCareer0.assignedTask'), ncsCareer0AssignedTask)

'NCS 경력사항 퇴사사유 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsCareer0.retirementRe'), ncsCareer0RetirementRe)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_experience_y'), 1)

'NCS 경험사항 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_experience_y'))

WebUI.delay(1)

'NCS 경험사항 능력단위 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/button_NCS_experience_ability'))

WebUI.delay(1)

'NCS 경험사항 능력단위 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_experience_ability_1'))

WebUI.delay(1)

'NCS 경험사항 활동구분 선택'
WebUI.selectOptionByLabel(findTestObject('Page_Company_Application_registResume_eduinfo/select_NCS_experience_activitycode'), 
    ncsExperienceActivitycode, true)

'NCS 경험사항 기관 및 조직명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input_  _ncsActivity0.organiza'), ncsActivity0Organization)

'NCS 경험사항 역할 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsActivity0.role'), ncsActivity0Role)

'NCS 경험사항 활동기간 시작일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsActivity0.startDate'), ncsActivity0StartDate)

'NCS 경험사항 활동기간 종료일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsActivity0.endDate'), ncsActivity0EndDate)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsActivity0.endDate'), Keys.chord(Keys.TAB))

'NCS 경험사항 활동내용 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsActivity0.assignedTa'), ncsActivity0AssignedTa)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_license_y'), 1)

'NCS 자격증 예 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_license_y'))

WebUI.delay(1)

WebUI.scrollToElement(findTestObject('Page_Company_Application_registResume_eduinfo/button_NCS_license_ability'), 1)

'NCS 자격증 능력단위 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/button_NCS_license_ability'))

WebUI.delay(1)

'NCS 자격증 능력단위 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_license_ability_4'))

WebUI.delay(1)

WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/label_search_license'))

'NCS 자격증검색 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/span_NCS_license_search'))

WebUI.delay(1)

'NCS 자격증명 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input_NCS_licensename'), ncsLicensename)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input_NCS_licensename'), Keys.chord(Keys.ENTER))

WebUI.delay(1)

'NCS 검색된 자격증 선택'
WebUI.click(findTestObject('Page_Company_Application_registResume_eduinfo/select_NCS_licensename'))

'NCS 자격증 발급기관 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsLicense0.organizatio'), ncsLisense0Organization)

'NCS 자격증 등록번호 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsLicense0.registNumbe'), ncsLisense0RegistNumber)

'NCS 자격증 발급일 입력'
WebUI.setText(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsLicense0.acquireDate'), ncsLisense0AcquireDate)

WebUI.sendKeys(findTestObject('Page_Company_Application_registResume_eduinfo/input__ncsLicense0.acquireDate'), Keys.chord(
        Keys.TAB))

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_save_temp'))

WebUI.delay(1)

String Step2Title = '이력서 작성 | ' + jobnoticename

WebUI.switchToWindowTitle(Step2Title)

WebUI.focus(findTestObject('Page_Company_Application_registResume_basicinfo/button_save_temp_y'))

'임시저장 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_save_temp_y'))

WebUI.delay(1)

WebUI.verifyElementPresent(findTestObject('Page_Company_Application_registResume_basicinfo/button_confirm_save_temp'), 1)

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_confirm_save_temp'))

WebUI.delay(1)

'다음 클릭'
WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button__Next'))

WebUI.switchToWindowTitle(Step2Title)

WebUI.switchToWindowTitle(Step2Title)

WebUI.focus(findTestObject('Page_Company_Application_registResume_basicinfo/button_next_y'))

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_next_y'))

WebUI.delay(1)

WebUI.click(findTestObject('Page_Company_Application_registResume_basicinfo/button_next_confirm'))

''', 'Test Cases/Company Site/CP_02_007_Application_RegistResume_eduinfo-4', new TestCaseBinding('Test Cases/Company Site/CP_02_007_Application_RegistResume_eduinfo-4',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
