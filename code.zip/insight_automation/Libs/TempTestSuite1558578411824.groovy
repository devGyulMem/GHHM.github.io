import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import internal.GlobalVariable as GlobalVariable

Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/002_RegistResume')

suiteProperties.put('name', '002_RegistResume')

suiteProperties.put('description', '\uC9C0\uC6D0\uC790\uAC00 \uCC44\uC6A9\uC0AC\uC774\uD2B8\uC5D0 \uC811\uC18D\uD55C \uD6C4 \uCC44\uC6A9\uACF5\uACE0\uB97C \uC120\uD0DD\uD558\uACE0 \uC774\uB825\uC11C\uB97C \uC791\uC131\uD55C\uB2E4.')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())



RunConfiguration.setExecutionSettingFile("D:\\insight_automation\\Reports\\002_RegistResume\\20190523_112651\\execution.properties")

TestCaseMain.beforeStart()

TestCaseMain.startTestSuite('Test Suites/002_RegistResume', suiteProperties, [new TestCaseBinding('Test Cases/Admin Site/AD_02_008_ManageApplicant_RegistApplicant', 'Test Cases/Admin Site/AD_02_008_ManageApplicant_RegistApplicant',  null), new TestCaseBinding('Test Cases/ETC/Close_Browser', 'Test Cases/ETC/Close_Browser',  null)])
