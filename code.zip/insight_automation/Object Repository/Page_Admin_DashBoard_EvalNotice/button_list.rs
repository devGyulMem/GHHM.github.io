<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_list</name>
   <tag></tag>
   <elementGuidId>d92304dc-b971-49be-b2c0-0d48047f13c8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='frmPage']/div/div/button[@id='btnList']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'btnList']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>btnList</value>
   </webElementProperties>
</WebElementEntity>
