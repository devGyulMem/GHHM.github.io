<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description>자기소개서 항목 조회</description>
   <name>getResumeDescription</name>
   <tag></tag>
   <elementGuidId>7deeb5a3-73ac-42bb-bdeb-4c43336398d8</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;&quot;,
  &quot;contentType&quot;: &quot;text/plain&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Accept-Language</name>
      <type>Main</type>
      <value>ko</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Accept-Encoding</name>
      <type>Main</type>
      <value>utf-8</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${API_Domain}/mrs2/api/getResumeDescription?COMPANY_AUTHORITY_KEY=${COMPANY_AUTHORITY_KEY}&amp;API_SERVICE_KEY=${API_SERVICE_KEY}&amp;recruitNoticeSn=${recruitNoticeSn}&amp;descriptionTypeCode=176</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>GlobalVariable.COMPANY_AUTHORITY_KEY</defaultValue>
      <description></description>
      <id>5d3fcb31-1393-43bb-a630-9e9378a3fce7</id>
      <masked>false</masked>
      <name>COMPANY_AUTHORITY_KEY</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_SERVICE_KEY</defaultValue>
      <description></description>
      <id>8be99e84-84b3-468b-bfd1-3d5e6d0b4ffb</id>
      <masked>false</masked>
      <name>API_SERVICE_KEY</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_Domain</defaultValue>
      <description></description>
      <id>d3303c9a-e50f-4759-9eb8-e836a61c1f8b</id>
      <masked>false</masked>
      <name>API_Domain</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_NoticeSn</defaultValue>
      <description></description>
      <id>7b291c22-dc7f-4ead-97b5-ebdc75cb6f44</id>
      <masked>false</masked>
      <name>recruitNoticeSn</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()
</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
