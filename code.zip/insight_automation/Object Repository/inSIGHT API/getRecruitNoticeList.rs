<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>getRecruitNoticeList</name>
   <tag></tag>
   <elementGuidId>27e53731-abc6-403e-ac35-b80c4df57a32</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;&quot;,
  &quot;contentType&quot;: &quot;text/plain&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json;charset=UTF-8</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${API_Domain}/mrs2/api/getRecruitNoticeList?COMPANY_AUTHORITY_KEY=${COMPANY_AUTHORITY_KEY}&amp;API_SERVICE_KEY=${API_SERVICE_KEY}&amp;isInprogress=1&amp;isPost=1</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>GlobalVariable.COMPANY_AUTHORITY_KEY</defaultValue>
      <description></description>
      <id>5d3fcb31-1393-43bb-a630-9e9378a3fce7</id>
      <masked>false</masked>
      <name>COMPANY_AUTHORITY_KEY</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_SERVICE_KEY</defaultValue>
      <description></description>
      <id>8be99e84-84b3-468b-bfd1-3d5e6d0b4ffb</id>
      <masked>false</masked>
      <name>API_SERVICE_KEY</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_Domain</defaultValue>
      <description></description>
      <id>a0e42d49-8cca-4de9-bdd9-fa6de583e9d2</id>
      <masked>false</masked>
      <name>API_Domain</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()

request.set

response.setContentType(&quot;&quot;)


WS.verifyResponseStatusCode(response, 200)

assertThat(response.getStatusCode()).isEqualTo(200)




</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
