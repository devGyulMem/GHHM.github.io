<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description>QnA작성</description>
   <name>writeApplicantQna</name>
   <tag></tag>
   <elementGuidId>38337a84-a563-4412-99ef-d5b22b5658a3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;&quot;,
  &quot;contentType&quot;: &quot;text/plain&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json;charset=UTF-8</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${API_Domain}/mrs2/api/writeApplicantQna?COMPANY_AUTHORITY_KEY=${COMPANY_AUTHORITY_KEY}&amp;API_SERVICE_KEY=${API_SERVICE_KEY}&amp;title=${Title}&amp;name=QA&amp;telephone=11111111111&amp;email=test@test.com&amp;isForeigner=true&amp;recruiteNoticeSn=${recruitNoticeSn}&amp;recruiteFieldSn=&amp;qnaTypeCode=03&amp;contents=APTTEST&amp;companySn=&amp;categorySn=</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>GlobalVariable.COMPANY_AUTHORITY_KEY</defaultValue>
      <description></description>
      <id>5d3fcb31-1393-43bb-a630-9e9378a3fce7</id>
      <masked>false</masked>
      <name>COMPANY_AUTHORITY_KEY</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_SERVICE_KEY</defaultValue>
      <description></description>
      <id>8be99e84-84b3-468b-bfd1-3d5e6d0b4ffb</id>
      <masked>false</masked>
      <name>API_SERVICE_KEY</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.QnA_Title</defaultValue>
      <description></description>
      <id>c7d61154-110c-463b-b70f-94eacac8a33e</id>
      <masked>false</masked>
      <name>Title</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_Domain</defaultValue>
      <description></description>
      <id>39ad62ba-578d-4305-8988-1c2149691ac0</id>
      <masked>false</masked>
      <name>API_Domain</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_NoticeSn</defaultValue>
      <description></description>
      <id>76de759a-4b95-4a68-bc94-df7e3d32cc21</id>
      <masked>false</masked>
      <name>recruitNoticeSn</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()
</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
