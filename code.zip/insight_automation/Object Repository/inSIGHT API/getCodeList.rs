<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description>코드 조회</description>
   <name>getCodeList</name>
   <tag></tag>
   <elementGuidId>186a7c08-2a9d-4289-8981-c3f465ed4e13</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;&quot;,
  &quot;contentType&quot;: &quot;text/plain&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${API_Domain}/api/getCodeList?COMPANY_AUTHORITY_KEY=${COMPANY_AUTHORITY_KEY}&amp;API_SERVICE_KEY=${API_SERVICE_KEY}&amp;category_id=17</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>GlobalVariable.COMPANY_AUTHORITY_KEY</defaultValue>
      <description></description>
      <id>5d3fcb31-1393-43bb-a630-9e9378a3fce7</id>
      <masked>false</masked>
      <name>COMPANY_AUTHORITY_KEY</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_SERVICE_KEY</defaultValue>
      <description></description>
      <id>8be99e84-84b3-468b-bfd1-3d5e6d0b4ffb</id>
      <masked>false</masked>
      <name>API_SERVICE_KEY</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.API_Domain</defaultValue>
      <description></description>
      <id>3745d4fb-3bc8-49d7-80fd-c9370dc8131d</id>
      <masked>false</masked>
      <name>API_Domain</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()
</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
