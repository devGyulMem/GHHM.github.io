<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_123456</name>
   <tag></tag>
   <elementGuidId>15da6874-3db3-44da-823c-b33ee7d36b82</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='큐에이큐시'])[1]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>wrap_body</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>layout</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	
		




 
 
 

    
	채용공고관리
		
			 채용공고현황
			 채용공고등록
			 채용코드관리
			
			 NCS코드관리
			
		
	
	지원자관리
		
			 공고별 지원자관리
			
			 상시지원자관리
				 지원서 삭제관리
			
			 지원자 검색허용
		
	
	
	외부시험연동
		
			 외부시험연동설정
		
	
	
	
	inSEED 관리
		
			 inSEED 현황
			 inSEED 등록
		
	
	
	채용전형관리
		
			 전형진행 현황
			 채용전형 등록
			 평가척도 설정
		
	
	
	전형안내 및 발표
		
			 안내 및 발표 현황
			 안내 및 발표 등록
		
	
	최종합격자 관리
		
			 최종합격자 확정
			 최종합격자 명단
		
	
	게시판 관리
		
			 지원자 공지사항
			 지원자 Q&amp;A
			
			 지원자 FAQ
			
             평가자 공지사항
             평가자 Q&amp;A
			 팝업창 관리
		
	
	메일/SMS 관리
		
			 메일 발송결과
			 메일발송 예약내역
			 SMS 발송결과
			 SMS발송 예약내역
		
	
	채용캠페인
		
			 채용캠페인 목록
			 채용캠페인 생성
			 채용캠페인 발송내역
		
	
	통계
		
		
	
	
		
		환경설정
			
				 기본설정
				 사용자 관리
				 시스템 로그관리
				 시스템 이용현황
				 서브관리자 현황
				 채용사이트 설정
				  비밀번호 변경
			
		
		
		
	
	서비스 선택
		midas Insight 1.0 관리자midas Insight 평가자midas inSEED이용 서비스 선택
	


	
	
	
		

기본설정
기초정보관리SMS발신번호관리시스템 알림설정시스템 접근설정평가자 서약서			대표 연락처		메일 및 SMS 발송 시 기본값으로 활용됩니다. 대표연락처를 변경하실 경우에는 로그아웃 후 재 접속해야 변경된 연락처로 메일/SMS 가 발송됩니다.																			대표 메일				           	               대표 전화번호	               					031-789-4177					관리	                   	                       정보통신망 법 개정 볍령 시행에 의해 SMS발신번호 사전등록제가 시행되었습니다.	                   	               	           				도움말 &amp; 지원센터			로그인 페이지에 안내되는 채용솔루션 담당자 정보입니다.					담당자 성명		전화번호 		E-mail 		검사 응시사이트 로그인 페이지에 안내되는 담당자 정보입니다.					담당자 성명		전화번호 		E-mail 			로고 정보					지원자 안내메일 및 지원자 사이트에 사용되는 로고 이미지 입니다. 미 설정 시 기본 로고가 보입니다.																								이미지 권장 사이즈 (210px * 70px)						파일선택																																																			로그인 페이지 및 메뉴영역에서 사용되는 로고 이미지입니다. 미 설정 시 기본로고가 보입니다.																								이미지 권장 사이즈 (210px * 70px)						파일선택																																																																	로그인 화면 이미지		로그인 페이지 배경으로 사용되는 이미지입니다. 미 설정 시 기본 이미지가 보입니다.																			로그인 페이지 배경 이미지(890px * 550px)					파일선택																																																		  				변경사항저장					   		  		로고 파일 첨부	  			  				  			JPG, GIF 또는 PNG 형식의 파일을 업로드할 수 있습니다. 권장사이즈는 210 * 70 입니다.	  			  			  		    	  		   		  			  			  		   	로고 선택 완료										  		로고 파일 첨부	  			  				  			JPG, GIF 또는 PNG 형식의 파일을 업로드할 수 있습니다. 권장사이즈는 210 * 70 입니다.	  			  			  				  				  			  			  			로고 선택 완료												로그인 이미지 파일 첨부											JPG, GIF 또는 PNG 형식의 파일을 업로드할 수 있습니다. 권장사이즈는 890 * 550 입니다.유명 인사의 이미지, 누드 이미지, 예술 이미지 또는 저작권으로 보호된 이미지는 업로드할 수 없습니다.																								이미지 선택 완료						SMS 발신번호 관리• 발신번호 사전등록제로 인해 등록된 발신번호로만 SMS 발송이 가능합니다.• 등록된 번호 중 상태값이 &quot;인증완료&quot;인 번호만 SMS 발송이 가능합니다.	선택삭제	대표번호 선택			번호 등록										이동			순번			명칭			전화번호			상태			수정			최종 인증방식			최초등록일			최종상태변경일				            1    대표번호    1588-0000     등록        통신서비스이용증명원     2019.03.1915:56:39    2019.03.1915:56:39            2    1    1588-1111     등록        통신서비스이용증명원     2019.03.2209:34:58    2019.03.2209:34:58            3    12    1588-1588     등록        통신서비스이용증명원     2019.03.2209:48:27    2019.03.2209:48:27            4    하하하    1588-9100     등록        통신서비스이용증명원     2019.03.2614:12:12    2019.03.2614:12:12	로그인 시 SMS 인증 사용											SMS 인증 사용여부									 사용안함				 사용 (본인 인증 후 로그인 허용)						※ SMS 인증 사용여부를 &quot;사용함&quot;으로 체크하신 경우라도 &quot;SMS/MMS 발송 가능건수&quot;가 모두 소진되면 자동으로 &quot;사용안함&quot; 상태로 변경됩니다.접속 가능 IP 대역 설정 시스템											접근제한 사용여부									 사용안함				 사용						※ 인터넷이 연결된 모든 컴퓨터에서 접근이 가능합니다.						접근가능 IP 대역															.	.	.	 ~	.	.	.												※ IP 대역의 기준은 내부 IP(ex: 192.168.10.23)가 아닌 외부 IP(ex:121.157.60.3)를 기준으로 동작합니다. 외부 IP가 아닌 내부 IP로 잘못 설정하시는 경우, 채용솔루션 접근에 문제가 생길 수 있습니다. IP 대역을 모르시는 경우, 내부 전산팀에 문의하시기 바랍니다.				접근제한 사용 시 SMS 인증을 통한 접근 허용여부									 사용안함				 사용함 (본인 인증 후 로그인 허용)						※ 접근 불가한 IP 대역에서 접속 시 SMS인증을 통해 본인 확인 후 로그인이 가능하도록 설정할 수 있습니다.			모바일 접근제한											모바일 접근제한									 사용안함				 사용			※ 테블릿을 포함한 모바일 디바이스에서 관리자 페이지 접근을 제한합니다.									 변경사항저장	


















	평가자 서약서  추천서식보기
	
		
			
				
				
				
			
			
				평가자 서약서 사용여부
				
					 사용
					 사용안함
				
			
		
	
	
		
			
		
		
		
			맵핑항목
			
			    $회사명$
				$전형명$
				$소속부서명$
				$평가자직급명$
				$평가자성명$
				$서명일자$
			
            
                
                    
                    맵핑 항목을 발표문에 적용하시려면
                    상단의 맵핑항목을 클릭하시거나
                    직접 타이핑치시면 됩니다.
                
                
                    
                    맵핑 항목을 위의 방식이 아니라
                    복사해서 붙여넣는 경우에는
                    정상적으로 동작하지 않습니다.
                
            
		
		
	
	
		 변경사항저장
	








	
		평가자 서약서 추천서식
		
		
			※ 평가자 서약서 추천서식을 적용하시겠습니까?
			
			
				적용하기
				직접 작성하기
			
			[추천 서식 예시]
			
			 
			
			
				
					
					
						평가자(전형위원) 서약서
						
							소속 : $회사명$ $소속부서명$
							직급 : $평가자직급명$
							성명 : $평가자성명$
						
						상기 본인은 $전형명$ 평가자(전형위원)으로서 평가를 실시함에 있어 엄정하고 공정하게 심사함은 물론 인사규정 제 25조(비밀엄수의 의무)에 의거 비밀(보안)을 유지할 것을 서약합니다.
						$서명일자$서약자 : 전형위원 $평가자성명$
					
												
				
			
	   	
	














	
		
			질문내역 알림설정 - 이메일
			
				
					
					
					
					
				
				
					
					
					
						지원자
						알림사용여부
						
							 사용안함
							 사용
						
						
							 설정큐에이큐시
						
					
					
						
						
							형태 및 시간대 설정
							
								 실시간 발송
								 통합 발송
							
							
						
						
						
							 ~ 
							
							매
							
								
									10분
									30분
									1시간
									3시간
								 
							
							마다 발송
						
					
					
				
					
					
					
						평가자
						알림사용여부
						
							 사용안함
							 사용
						
						
							 설정
						
					
					
						
						
							형태 및 시간대 설정
							
								 실시간 발송
								 통합 발송
							
							
						
						
						
							 ~ 
							
							매
							
								
									10분
									30분
									1시간
									3시간
								 
							
							마다 발송
						
					
					
				
			
		
	
		
			질문내역 알림설정 - SMS
			
				
					
					
					
					
				
				
					
					
					
						지원자
						알림사용여부
						
							 사용안함
							 사용
						
						
							 설정큐에이큐시 외 1명
						
					
					
						
						
						
							수신 시간대 설정
							
						
						
							 ~ 
							
							매
							
								
									10분
									30분
									1시간
									3시간
								 
							
							마다 발송
						
					
					
				
					
					
					
						평가자
						알림사용여부
						
							 사용안함
							 사용
						
						
							 설정
						
					
					
						
						
						
							수신 시간대 설정
							
						
						
							 ~ 
							
							매
							
								
									10분
									30분
									1시간
									3시간
								 
							
							마다 발송
						
					
					
						
							방해금지 시간대 설정
							
								 사용안함
								 사용
							
							
								 ~
								
							
						
					
				
			
		
	
	
  	
		 변경사항저장
	
	
	
		이용안내
		
			실시간 발송 : Q&amp;A 등록시, 수신 대상자에게 내용 즉시 발송
			통합 발송 : 설정된 시간 내에만 발송되며, 수신 주기를 설정하여 Q&amp;A가 있는 경우 발송
			SMS/MMS 발송건수가 모두 소진된 경우 SMS가 발송되지 않습니다.
		
	











		
	
</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrap_body&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='큐에이큐시'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[2]</value>
   </webElementXpaths>
</WebElementEntity>
