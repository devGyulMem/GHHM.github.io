package userdefinepkg

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import groovy.time.TimeCategory as TimeCategory

import internal.GlobalVariable

public class timeExpression {
	@Keyword
	def getDate(){
		Date today = new Date()
		return today
	}
	Date temps
	@Keyword
	def getHour(Date present){
		return present.format('hh')
	}
	@Keyword
	def getMinute(Date present){
		return present.format('mm')
	}
	@Keyword
	def getYMD(Date present){
		return present.format('yyyyMMdd')
	}
	@Keyword
	def getYMD_dot(Date present){
		return present.format('yyyy.MM.dd')
	}
	@Keyword
	def getYMDHM(Date present){
		return present.format('yyyyMMddhhmm')
	}
	@Keyword
	def getYMDHMS(Date present){
		return present.format('yyyyMMddhhmmss.S')
	}
	@Keyword
	def addAMonth(Date present){
		use(TimeCategory, { temps = present + 1.month })
		return temps
	}
	@Keyword
	def addADay(Date present){
		use(TimeCategory, { temps = present + 1.day })
		return temps
	}
	@Keyword
	def addNMinute(Date present, int n){
		use(TimeCategory, {temps = present + n.minute})
		return temps
	}
	@Keyword
	def addNHour(Date present, int n){
		use(TimeCategory, {temps = present + n.hour})
		return temps
	}
	@Keyword
	def addNDay(Date present, int n){
		use(TimeCategory, {temps = present + n.day})
		return temps
	}
	@Keyword
	def addNMonth(Date present, int n){
		use(TimeCategory, {temps = present + n.month})
		return temps
	}
	@Keyword
	def addNYear(Date present, int n){
		use(TimeCategory, {temps = present + n.year})
		return temps
	}
	@Keyword
	def getCurrentTime(){
		Date present = new Date()
		return present.format('yyyyMMddhhmmss.S')
	}
	@Keyword
	def getHMSCurrentTime(){
		Date present = new Date()
		return present.format('hhmmss.S')
	}
}